package camelinaction;

public interface Greeter {
    public String sayHello();
}
