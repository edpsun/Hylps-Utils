Camel Component Project
====================
This Project is a template of the Camel component.
When you create the component project , you need to move the META-INF/services/direct file to META-INF/services/PACKAGE_NAME/FOO where FOO is the URI scheme for your component and any related endpoints created on the fly and PACKAGE_NAME is your component's package name which is replaced the '.' with '/'.

For more help see the Apache Camel documentation

    http://cwiki.apache.org/CAMEL/writing-components.html
    