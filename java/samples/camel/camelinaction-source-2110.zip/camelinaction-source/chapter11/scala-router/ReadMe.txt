Camel Router with Scala DSL Project
===================================

To run this router either embed the jar inside Spring
or to run the route from within maven try

    mvn camel:run
    
This project builds an OSGi bundle that can be used to
embed the Camel routes in ServiceMix Kernel or another
OSGi runtime.

For more help see the Apache Camel documentation

    http://camel.apache.org/

