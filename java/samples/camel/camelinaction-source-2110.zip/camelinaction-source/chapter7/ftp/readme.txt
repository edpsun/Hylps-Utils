FTP Component Example
------------------------

Writing Files to FTP server
---------------------------

To run this example, execute the following command:

mvn camel:run

You will need to enter some text input after the 
"Enter something:" prompt.

