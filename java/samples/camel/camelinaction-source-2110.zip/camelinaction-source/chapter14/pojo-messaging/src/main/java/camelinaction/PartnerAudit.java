package camelinaction;

public interface PartnerAudit {
    public void audit(Inventory inventory);
}
